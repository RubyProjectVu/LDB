require 'test_helper'

class NotesManagerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
