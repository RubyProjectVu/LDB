class WorkGroup < ApplicationRecord
end
