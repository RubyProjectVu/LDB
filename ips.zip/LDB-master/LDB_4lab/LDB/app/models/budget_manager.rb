class BudgetManager < ApplicationRecord
end
