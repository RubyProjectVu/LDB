class WorkGroupManager < ApplicationRecord
end
