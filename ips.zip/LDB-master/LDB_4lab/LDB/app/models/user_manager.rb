class UserManager < ApplicationRecord
end
