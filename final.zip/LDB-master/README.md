
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

Leisti rspec kaip ```LDB_3lab/spec```; ```rspec *spec.rb```

Leisti mutant kaip ```LDB_3lab```; ```./run.sh```. Atsiklonavus saka is github isitikinti, kad run.sh turi leidima buti paleistam kaip executable file.

LDB_3lab padengimas: 100%

Project: 100

ProjectManager: 100

User: 100

UserManager: 100

WorkGroup: 100

WorkGroupManager: 100

BudgetManager: 100

NotesManager: 100

Search: 100

155 ex.

9 custom matchers

25 standard matchers listed on ```LDB_3lab```, as ```expects```

reek klaidos: 0. rubocop klaidos: 0

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.

# Esantis funkcionalumas

...bus papildyta 18-11-05...
