# frozen_string_literal: true

require 'date'
require 'etc'
require_relative 'project'
require './application_record'
require 'yaml'

# Manages user notes
class NotesManager < ApplicationRecord
  def save_note(author, name, text)
    # validator method?
    return false if name.eql?('Back') || bad_words_included?(text)

    NotesManager.create(name: name, author: author, text: text)
  end

  def bad_words_included?(text)
    # Could probably be moved to a text file, line by line
    list = %w[bad bad\ word really\ bad\ word]
    list.each do |t|
      return true if text.match?(t)
    end
    false
  end

  def check_outdated
    outd = []
    list = NotesManager.all
    list.each do |note|
      next if [nil].include?(note.expire)

      outd.push(note.name) if note.expire <= DateTime.current
    end
    outd
  end

  def list_notes
    check_outdated
    arr = []
    lofids = NotesManager.all.ids
    lofids.each do |id|
      arr.push(NotesManager.find_by(id: id).name)
    end
    arr
  end

  def note_getter(name)
    note = NotesManager.find_by(name: name)
    return false if [nil].include?(note)

    note.text
  end

  def delete_note(name)
    note = NotesManager.find_by(name: name)
    note.destroy
    true
  end
end
