
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

LDB_3lab padengimas: 84.53% (pridėjus BudgetManager ir NotesManager bus mažiau, jie išvis nedengti)

project: 100

projectmanager: 68.79

user: 96.15

usermanager: 89

workgroup: 75.65

workgroupmanager: 88.32

budgetmanager: -/-

notesmanager: -/-

89 ex.

2 custom matchers

LDB_3lab reek klaidos: 13. rubocop klaidos: 21

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.
