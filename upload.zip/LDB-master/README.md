
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

Leisti rspec is ```LDB_3lab/spec```; ```rspec *spec.rb```

LDB_3lab padengimas: 82.70%

Project: 100

ProjectManager: 70.67

User: 96.15

UserManager: 89

WorkGroup: 76.39

WorkGroupManager: 87.01

BudgetManager: 43.5

NotesManager: 93.81

101 ex.

4 custom matchers

LDB_3lab reek klaidos: 2. rubocop klaidos: 1

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.

# Esantis funkcionalumas

...bus papildyta...
