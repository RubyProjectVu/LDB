
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

LDB_3lab padengimas: 84.53% (pridėjus BudgetManager ir NotesManager bus mažiau, jie išvis nedengti)

92 ex.

2 custom matchers

LDB_3lab reek klaidos: 8. rubocop klaidos: 23

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.
