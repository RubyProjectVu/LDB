
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Tests

LDB_3lab coverage: 84.53%

92 ex.

2 custom matchers

LDB_3lab reek errors: 8. rubocop errors: 23

# Ruby styling check
Run reek as root user with ```sudo reek```. Otherwise the UI file does not get excluded as per
reek.yml configuration.
reek and rubocop is launched regularly inside directory.
