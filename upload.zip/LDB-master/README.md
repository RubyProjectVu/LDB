
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

Leisti rspec is ```LDB_3lab/spec```; ```rspec *spec.rb```

LDB_3lab padengimas: 93.97%

Project: 100

ProjectManager: 100

User: 100

UserManager: 100

WorkGroup: 100

WorkGroupManager: 87.01

BudgetManager: 43.5

NotesManager: 100

115 ex.

4 custom matchers

reek klaidos: 1. rubocop klaidos: 1

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.

# Esantis funkcionalumas

...bus papildyta 18-11-05...
