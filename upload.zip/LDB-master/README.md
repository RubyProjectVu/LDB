
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Testai

Leisti rspec is ```LDB_3lab/spec```; ```rspec *spec.rb```

LDB_3lab padengimas: 82.70%

project: 100

projectmanager: 70.67

user: 96.15

usermanager: 89

workgroup: 76.39

workgroupmanager: 87.01

budgetmanager: 43.5

notesmanager: 93.81

98 ex.

2 custom matchers

LDB_3lab reek klaidos: 2. rubocop klaidos: 1

# Ruby stilius
Leisti reek kaip root ```sudo reek```. Kitu atveju reek.yml failo konfigūracijos nepasigriebia.
rubocop leidžiamas įprastai.

# Esantis funkcionalumas

...bus papildyta...
