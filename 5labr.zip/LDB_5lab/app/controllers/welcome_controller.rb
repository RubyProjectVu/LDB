# frozen_string_literal: true

# has a main screen
class WelcomeController < ApplicationController
  def index; end
end
