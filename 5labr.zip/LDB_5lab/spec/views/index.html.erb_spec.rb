# frozen_string_literal: true

require_relative '../rails_helper'

describe 'welcome/index' do
  it '' do
    render
    # puts rendered
  end
end
