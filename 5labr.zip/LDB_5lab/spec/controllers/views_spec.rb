# frozen_string_literal: true

require_relative '../rails_helper'

describe OrdersController do
  include Devise::Test::ControllerHelpers
  render_views

  before do
    allow_any_instance_of(described_class).to receive(:current_user).and_return({'email'=>'Tomas'})
    # Cannot use sign_in since Tomas does not actually exist
  end

  it 'renders orders in page' do
    get :index
    out = response.body
                  .match?('|Order id: 15| 2018-08-05 00:00:00 UTC 100.0 WoodWorks 0.0 U8856SPPA131310') &&
          response.body.match?('|Order id: 16| 2018-08-01 00:00:00 UTC 200.0 Choppers 0.0 U8856SPPA131310') &&
          response.body.match?('|Order id: 17| 2018-11-16 00:00:00 UTC 1500.0 SteelPool 9.0 U7856Y11A13HH1L') &&
          response.body.match?('Steve 50.0 pcs Supports |Project id: 102050|')
    expect(out).to be true
  end

  it do
    get :index
    arr = []
    assigns(:my_orders).each do |o|
      o.each do |ord|
        arr.push(ord.material)
      end
    end
    expect(arr).to eq %w[Planks Planks Supports]
  end
end

describe MaterialsController do
  include Devise::Test::ControllerHelpers
  render_views

  it 'renders providers in page' do
    get :index
    out = response.body.match?('Choppers') &&
          response.body.match?('SteelPool') &&
          response.body.match?('WoodWorks')
    expect(out).to be true
  end

  it 'renders offers in page' do
    get :index
    out = response.body.match?('WoodWorks Planks 30000 10.0') &&
          response.body.match?('Choppers Planks 350 20.0') &&
          response.body.match?('WoodWorks Boards 5000 15.5')
    expect(out).to be true
  end
end

describe ProjectsController do
  include Devise::Test::ControllerHelpers
  render_views

  it 'renders form only' do
    get :create
    expect(response.body).to match('"submit" name="commit" value="Create"')
  end

  it 'sets the variable on page loading' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(assigns(:projects)).not_to be nil
  end

  it 'actually loads projects' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(response.body).to match('|201050| act8 In progress 200.0')
  end

  it 'covers mutation manager: nil/"" ' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(assigns(:projects).first.name).to eq 'act8'
  end
end

describe WelcomeController do
  include Devise::Test::ControllerHelpers
  render_views
end

describe UsersController do
  include Devise::Test::ControllerHelpers
  render_views

  let(:upd_hash) do
    { :user => { :email => 'tg@gmail.com', :pass => '-4',
                 :name => 'nn', :lname => 'nl' } }
  end

  it 'renders correct default value fill-ins' do
    sign_in(User.find_by(email: 'tg@gmail.com'))
    get :index, params: { :method => 'edit' }
    expect(response.body).to match("Email: tg@gmail.com")
  end
end

describe WgsController do
  include Devise::Test::ControllerHelpers
  render_views
  fixtures :all

  let(:upd_hash) do
    { :user => { :email => 'tg@gmail.com', :pass => '-4',
                 :name => 'nn', :lname => 'nl' } }
  end

  it 'renders hidden id to pass later' do
    get :addmem
    expect(response.body).to match("input type=\"hidden\" name=\"id\" id=\"id\"")
  end

  it 'actually loads managed workgroups' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(response.body).to match("|Project id: 201050| Trecia grupe 10.0")
  end

  it 'covers mutation current_user[nil/self]' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(response.body).not_to match("nilly 10.0")
  end

  it 'project is not set to nil when it is not supposed to' do
    sign_in(User.find_by(email: 'ar@gmail.com'))
    get :index
    expect(assigns(:projects)).not_to be nil
  end

  it 'no user raises error' do
    expect {get :index}.to raise_error(NoMethodError)
  end

  it 'different user renders different workgroups' do
    allow_any_instance_of(described_class).to receive(:current_user).and_return({'email'=>'Tomas'})
    # Cannot use sign_in since Tomas does not actually exist
    get :index
    expect(response.body).to match("|Project id: 101050| Trecia grupe 10.0")
  end
end

describe TasksController do
  include Devise::Test::ControllerHelpers
  render_views

  it 'renders correct tasks' do
    get :index
    out = response.body.match?('finish something') &&
          response.body.match?('do not read this')
    expect(out).to be true
  end
end

describe SearchController do
  include Devise::Test::ControllerHelpers
  render_views

  let(:all_params) do
    { :proj => 'Project', :wgs => 'WorkGroup', :usr => 'User', 'tsk' => 'Task',
      :note => 'NotesManager', :ordr => 'Order',
      :search => { :value => 'Tomas' } }
  end

  it do
    get :show, params: all_params
    out = response.body.match?('User has:  Tomas') &&
          response.body.match?('Project has:  Tomas')
    expect(out).to be true
  end

  it do
    get :show, params: { :tsk => 'Task', :search => { :value => 'finish something' } }
    out = response.body.match?('Task has:  finish something')
    expect(out).to be true
  end

  it do
    get :show, params: { :note => 'NotesManager', :search => { :value => 'Uzrasas3' } }
    out = response.body.match?('NotesManager has:  Uzrasas3')
    expect(out).to be true
  end

  it do
    get :show, params: { :ordr => 'Order', :search => { :value => 'U7856Y11A13HH1L' } }
    out = response.body.match?('Order has:  U7856Y11A13HH1L')
    expect(out).to be true
  end

  it do
    get :show, params: { :wgs => 'WorkGroup', :search => { :value => 'Antra grupe' } }
    out = response.body.match?('WorkGroup has:  Antra grupe')
    expect(out).to be true
  end

  it 'covers -unless mutation in gathering' do
    expect {get :show}.not_to raise_error(NoMethodError)
  end
end
