# frozen_string_literal: true

require_relative '../rails_helper'

describe WelcomeController do
  include Devise::Test::ControllerHelpers
  render_views
end
