# frozen_string_literal: true

require_relative '../rails_helper'

describe WelcomeController do
  it do
  end
end
