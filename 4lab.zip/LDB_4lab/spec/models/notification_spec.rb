# frozen_string_literal: true

require_relative 'custom_matcher'
require_relative '../rails_helper'

describe Notification do
  fixtures :all
end
