# frozen_string_literal: true

require_relative 'custom_matcher'
require_relative '../rails_helper'

describe Notification do
  fixtures :all

  it 'empty' do
    # something
  end
end
