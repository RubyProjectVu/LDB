class NotesManager < ApplicationRecord
end
