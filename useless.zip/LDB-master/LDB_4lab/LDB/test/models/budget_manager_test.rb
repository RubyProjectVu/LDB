require 'test_helper'

class BudgetManagerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
