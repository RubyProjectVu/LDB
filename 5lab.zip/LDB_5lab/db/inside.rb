puts User.all
