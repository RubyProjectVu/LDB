class UsersController < ApplicationController
  def index
    @users = User.all
  end

  def show
  end

  def new
    @user = User.new
  end

  def create
  end

  def edit
  end

  def update
  end

  def destroy
  end

  # def login
  # end

  def parse_signup
    result = UserManager.new.register([params[:user][:name], params[:user][:lname]], params[:user][:email], params[:user][:pass])
    flash[:error] = 'Could not register with specified entries' unless result

    redirect_to :controller => 'welcome', :action => 'index'
  end

  def parse_login
    result = UserManager.new.login(params[:user][:email], params[:user][:pass])
    if result
      redirect_to :controller => 'menus', :action => 'main', :allowed => true and return
    end

    flash[:error] = 'Could not login: Incorrect credentials'
    redirect_to :controller => 'welcome', :action => 'index'
  end
end
