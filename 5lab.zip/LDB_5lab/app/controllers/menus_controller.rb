class MenusController < ApplicationController
  def index
  end

  def show
  end

  def new
  end

  def create
  end

  def edit
  end

  def update
  end

  def destroy
  end

  def main
    # raise user_signed_in?.to_s
    # redirect_to :controller => 'welcome', :action => 'index' unless params[:allowed]
  end
end
