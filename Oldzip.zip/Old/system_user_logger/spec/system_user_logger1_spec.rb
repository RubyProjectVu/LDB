# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/system_user_logger'
require_relative '../lib/system'
require_relative '../lib/user'
require_relative '../lib/project'
require 'time'

describe SystemUserLogger do
  let(:sul) { described_class.new(['name', 'lname', '1', '', 'fl.pdf']) }

  it 'is two' do
    System.new.login(User.new(name: 'name', last_name: 'lname'))
    expect(System.new.latest_entry).to start_with 'User: ["name", '\
                                                  '"lname"]  logs in'
  end

  it 'is four' do
    expect(sul.log_user_logout).to be nil
  end

  it 'is five' do
    expect(System.new.latest_entry).to start_with 'User: name lname logs out'
  end

  it 'is six' do
    sys1 = System.new
    expect(sys1.latest_entry).to include '2018-'
  end

  context do
    it 'is seven' do
      sul.log_password_request
      expect(System.new.latest_entry).to start_with 'Password request for ' \
                                                  'user: 1'
    end
  end

  it 'is eight' do
    expect(System.new.latest_entry).to include '2018-'
  end
end
