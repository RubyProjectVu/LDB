# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/system_user_logger'
require_relative '../lib/system'
require_relative '../lib/user'
require_relative '../lib/project'
require 'time'

describe SystemUserLogger do
  let(:sul) { described_class.new(['name', 'lname', '1', '', 'fl.pdf']) }

  context do
    it 'is seven' do
      sul.log_password_request
      expect(System.new.latest_entry).to start_with 'Password request for ' \
                                                  'user: 1'
    end
  end

  it 'is eight' do
    expect(System.new.latest_entry).to include '2018-'
  end
end
