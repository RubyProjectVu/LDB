# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/system_user_logger'
require_relative '../lib/system'
require 'time'

describe SystemUserLogger do
  let(:sul) { described_class.new(['name', 'lname', '1', '', 'fl.pdf']) }

  it 'is one' do
    expect(sul.log_user_login).to be nil
  end

  it 'is three' do
    expect(System.new.latest_entry).to include '2018-'
  end

  it 'is nine' do
    sul.log_certificate_upload
    expect(System.new.latest_entry).to start_with 'User: name lname uploaded' \
                                                  ' a certification fl.pdf at'
  end

  it 'is ten' do
    sys2 = System.new
    expect(sys2.latest_entry).to include '2018-'
  end
end
