# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/project'
require_relative '../lib/user'
require_relative '../lib/system'
require_relative '../lib/work_group'
require_relative '../lib/system_group_logger'
require_relative '../lib/system_user_logger'
require_relative '../lib/system_project_logger'
require_relative '../lib/project_data_checker'
require_relative '../lib/user_data_checker'

describe System do
  it 'The system should log a user logout' do
    sys = described_class.new
    usr = User.new(name: 'tomas', last_name: 'genut', email: 't@a.com')
    sys.login(usr)
    # sys.log_user_login_logout('tomas', 'genut')
    sys.logout(usr)
    # sys.log_user_login_logout('tomas', 'genut', false)
    expect(sys.latest_entry).to start_with 'User: ["tomas", "genut"] '
    # expect(sys.latest_entry).to include('logs out at')
  end

  it 'The system should log a request and see the email and user' do
    # sys = described_class.new
    e = 'emailname@gmail.com'
    usr = User.new(name: 'some name', last_name: 'pavardenis', email: e)
    usr.resend_password_link
    # e = 'emailname@gmail.com'
    # sys.log_password_request('some name', 'pavardenis', e)
    # s1 = 'Password request for user:'
    expect(described_class.new.latest_entry).to start_with 'Password ' \
                                                           'request for user:'
  end
end
