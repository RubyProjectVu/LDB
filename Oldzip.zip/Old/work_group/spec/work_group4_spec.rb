# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/work_group'
require_relative '../lib/user'
require_relative '../lib/system_project_logger'
require_relative '../lib/system'

describe WorkGroup do
  let(:group) { described_class.new }

  it do
    usr = User.new
    group.add_member(usr)
    group.remove_member(usr)
    expect(group.remove_member(usr)).to be false
  end

  it do
    expect(group.deleted_status_setter(User.new)).not_to be nil
  end

  it do
    group.deleted_status_setter(User.new)
    expect(group.deleted_status_setter(User.new)).to be false
  end
end
