# frozen_string_literal: true

require 'securerandom' # random hash kuriantis metodas yra
require_relative 'project'
require_relative 'work_group'
require 'uri'

# Documentation about class User
class User
  # attr_reader :info
  # attr_reader :name
  # attr_reader :last_name
  # attr_reader :email
  # attr_reader :gender -> To address book
  # attr_reader :user_id
  # attr_reader :phone_number -> To address book
  # attr_reader :projects

  def initialize(name: '', last_name: '', email: '')
    @info = { name: name, lname: last_name, email: email, pass: '123', lobject: ''}
    # @info[0] = name
    # @info[1] = last_name
    # @info[2] = email
    # @name = name
    # @last_name = last_name
    # @email = email
    # @phone_number = phone_number
    @projects = {}
    # @qualification_certificates = [] Nebuvo naudotas? Galesim det i DB 'file'
    # @user_id = ''
  end

  def data_getter(key)
    @info.fetch(key.to_sym)
  end

  # def user_input_validation
  #  if !@info[0].match(/[a-zA-Z][a-z]+/) ||
  #     !@info[1].match(/[a-zA-Z][a-z]+/) ||
  #     !@info[2].match(/[a-zA-Z0-9]+[@][a-zA-Z0-9]+[.][a-zA-Z]+/)
  #    return false
  #  end
  #
  #  true
  # end

  def prepare_deletion
    return true unless active_projects_present?

    # should ideally mark userid as deleted on another entity {.yml}
    # return true
    # else
    # should ideally contact project managers
    false
    # end
  end

  def active_projects_present?
    @projects.each do |_name, status|
      return true if status.eql? 'In progress'
    end
    false
  end

  def add_project(project, status)
    # should ideally determine if project manager approves first
    # key = project.to_s.to_sym
    @projects[project] = status
  end

  # def change_project_status(project, status)
  # key = project.to_s.to_sym
  # @projects[project] = status
  # end

  def create_project(project_name, file_name)
    # object =
    # sysprojlog = SystemProjectLogger.new([project_name, @user_id, file_name])
    # sysprojlog.log_project_creation
    @info[:lobject] = 'Project'
    Project.new(project_name: project_name, meta_filename: file_name)
    # return object
  end

  def projects_getter
    @projects
  end

  # def delete_project(proj)
  #  if proj.nil?
  # puts 'Invalid object reference'
  #    return false
  #  end
  #
  #  proj.set_deleted_status
  # end

  def create_work_group(work_group_name)
    # sysgrlog = SystemGroupLogger.new([work_group_name, @user_id])
    # sysgrlog.log_work_group_creation
    @info[:lobject] = 'WGroup'
    WorkGroup.new(work_group_name: work_group_name)
  end

  # def delete_work_group(group)
  #  if group.nil?
  # puts 'Invalid object reference'
  #    return false
  #  end
  #
  #  group.set_deleted_status(@user_id)
  # end

  def upload_certificate(file)
    @info['lobject'] = Regexp.new('([a-zA-Z0-9_.\-])+(.doc|.docx|.pdf)$')
    # sysusrlogger = SystemUserLogger.new([@info[0], @info[1], '', '', file])
    return true if @info.fetch('lobject').match?(file)

    false
  end

  def password_set(new)
    # should later (5 laboras) work based on Rails gem 'EmailVeracity'
    @info[:pass] = new
  end
end
