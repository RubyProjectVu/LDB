# frozen_string_literal: true

require_relative 'user'
require 'time'
require 'yaml'

# this is System class description
class System
  # attr_reader :users
  # attr_reader :collection
  # attr_reader :state

  def initialize
    @users = YAML.load_file('users.yml')
  end

  def login(user_to_login)
    @users.fetch('users').fetch(user_to_login)
    true
  end

  def last_use(arg)
    # arg kills mutations
    @users.fetch('lastuse').fetch(arg)
  end

  # def try_logging_in(user_to_login)
    # return false unless user_to_login.instance_of?(User)
    # return false if already_logged_in?(user_to_login)

    # sysusrlog = SystemUserLogger.new([user_to_login.name_lastname_getter])
    # sysusrlog.log_user_login
    # @logged_in_users.push(user_to_login.unique_id_getter)
    # true
  # end

  # def log_user_login_logout(name, last_name, logs_in = true)
  #  false if @state == false
  #  time = Time.now.getutc
  #  File.open('syslog.txt', 'a') do |log|
  #    if logs_in
  #      log.puts "User: #{name} #{last_name} logs in at #{time}."
  #    else
  #      log.puts "User: #{name} #{last_name} logs out at #{time}."
  #    end
  #  end
  # end

  # def log_password_request(name, last_name, email)
  #  false if @state == false
  #  File.open('syslog.txt', 'a') do |log|
  #    sho = [Time.now.getutc, name]
  #    interpolated_text = "#{sho[1]} #{last_name} to #{email} at #{sho[0]}."
  #    log.puts 'Pass req for user: ' + interpolated_text
  #  end
  # end

  # def log_certificate_upload(name, last_name, file)
  #  @state = true
  #  File.open('syslog.txt', 'a') do |log|
  #    time_now = Time.now.getutc
  #    certification_text = 'uploaded a certification '
  #    log_text = "User: #{name} #{last_name} "
  #    log_text += certification_text
  #    log_text += "#{file} at #{time_now}."

  #    log.puts log_text
  #  end
  # end

  # def log_project_deletion(name, user)
  #  FFile.open('syslog.txt', 'a') do |log|
  #    log.puts "Project: #{name} del
  #  end
  # end

  # def log_work_group_creation(name, user)
  #  @state = true
  #  File.open('syslog.txt', 'a') do |log|
  #    vv = user.unique_id_getter
  #    vd = Time.now.getutc
  #    log.puts "Work group: #{name} created by #{vv} at #{vd}."
  #  end
  # end

  # def log_work_group_deletion(name, user)
  #  false unless @state
  #  File.open('syslog.txt', 'a') do |log|
  #    vv = user.unique_id_getter
  #    vd = Time.now.getutc
  #    log.puts "Work group: #{name} deleted by #{vv} at #{vd}."
  #  end
  # end

  # def latest_entry
    # false if @state == false
    # File.readlines('syslog.txt').last
    # lines.last
  # end
end
