# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/project_data_checker'
require_relative '../lib/user'

describe ProjectDataChecker do
  let(:pdc) { described_class.new('meta3.txt') }

  it do
    expect(pdc.create_file('temp.txt')).to be true
  end

  it do
    expect(pdc.delete_file('temp.txt')).to be true
  end

  it do
    expect(pdc.get_two_metas('metadata2.txt')).to be_truthy
  end

  it do
    expect(pdc.own_meta_line_getter).to start_with 'manager: n'
  end

  it do
    expect(pdc.manager_from_meta_getter).to start_with 'name'
  end
end
