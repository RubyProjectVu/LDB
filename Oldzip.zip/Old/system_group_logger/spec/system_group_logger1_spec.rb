# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/system_group_logger'
require_relative '../lib/work_group'
require_relative '../lib/system'

describe SystemGroupLogger do
  let(:group) { WorkGroup.new }
  let(:sys) { System.new }
  let(:sgl) { described_class.new([group.parm_work_group_name, '1']) }

  it do
    expect(sgl.log_work_group_creation).to be nil
  end

  it do
    expect(sys.latest_entry).to start_with 'Work group:'
  end

  it do
    expect(sgl.log_work_group_deletion).to be nil
  end

  it do
    sys1 = System.new
    expect(sys1.latest_entry).to start_with 'Work group:'
  end
end
