# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/user'
require_relative '../lib/system'
require_relative '../lib/project'
require_relative '../lib/system_user_logger'
require_relative '../lib/system_group_logger'
require_relative '../lib/system_project_logger'

describe User do
  let(:usr) { described_class.new }

  it do
    expect(usr.name_lastname_getter).not_to be nil
  end

  it do
    expect(usr.email_getter).not_to be nil
  end

  it do
    expect(usr.user_input_validation).not_to be nil
  end

  it do
    expect(usr.unique_id_getter).not_to be nil
  end

  it do
    proj = Project.new
    proj.parm_project_status('In progress')
    usr.add_project(proj.parm_project_name,
                    proj.parm_project_status)
    expect(usr.gather_active_projects).not_to be nil
  end
end
