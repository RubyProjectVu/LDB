# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/system_project_logger'
require_relative '../lib/system'
require 'time'

describe SystemProjectLogger do
  let(:spl) { described_class.new(['name', '1', '']) }

  it do
    expect(spl.log_project_creation).to be nil
  end

  it do
    expect(System.new.latest_entry).to start_with 'Project: name created by 1'
  end

  it do
    expect(System.new.latest_entry).to include '2018-'
  end
end
