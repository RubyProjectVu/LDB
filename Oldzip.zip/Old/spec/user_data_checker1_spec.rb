# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/user_data_checker'
require_relative '../lib/system'
require_relative '../lib/user'
require 'time'

describe UserDataChecker do
  let(:udc) { described_class.new }
  let(:usr) { User.new(name: 'name', last_name: 'lname', email: 'mail') }

  it 'is one' do
    expect(udc.users_getter).not_to be nil
  end

  it 'is two' do
    expect(udc.register(usr)).to be true
  end

  it'is three' do
    usr = User.new(name: 'name', last_name: 'lname', email: 't@a.com')
    expect(udc.register(usr)).to be false
  end
end
