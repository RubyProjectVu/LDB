# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/work_group'
require_relative '../lib/user'
# require_relative '../lib/system_project_logger'
require_relative '../lib/system'

describe WorkGroup do
  let(:group) { described_class.new }

  it do
    expect(group.parm_manager).not_to be nil
  end

  it do
    expect(group.parm_work_group_name).not_to be nil
  end

  it do
    expect(group.add_member(User.new)).not_to be nil
  end

  it do
    expect(group.remove_member(User.new)).not_to be nil
  end

  # it do
    # group.deleted_status_setter
    # expect(System.new.latest_entry).to start_with 'Work group: Default'
  # end
end
