# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/project'
require_relative '../lib/user'

describe Project do
  let(:pr) { described_class.new }
  let(:usr) { User.new }

  it do
    pr.set_deleted_status
    expect(pr.parm_project_status).to eq 'Deleted'
  end

  it do
    expect(pr.parm_manager).to be_truthy
  end

  it do
    expect(pr.remove_subscriber('name')).to be false
  end

  it do
    expect(pr.add_subscriber('name', 'mail')).not_to be_falsey
  end

  it do
    expect(pr.set_deleted_status).to be true
  end

  it do
    expect(pr.add_member(usr)).to be true
  end

  it do
    # id is blank
    expect(pr.remove_member(usr)).to be false
  end
end
