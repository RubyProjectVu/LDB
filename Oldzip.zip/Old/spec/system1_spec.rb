# frozen_string_literal: true

require 'simplecov'
SimpleCov.start

require_relative '../lib/project'
require_relative '../lib/user'
require_relative '../lib/system'
require_relative '../lib/work_group'
# require_relative '../lib/system_group_logger'
# require_relative '../lib/system_user_logger'
# require_relative '../lib/system_project_logger'
require_relative '../lib/project_data_checker'
require_relative '../lib/user_data_checker'

describe System do
  it do
    sys = described_class.new
    #usr = User.new(name: 'tomas', last_name: 'genut', email: 't@a.com')
    #usr.unique_id_setter('48c7dcc645d82e57f049bd414daa5ae2')
    expect(sys.login('t@a.com')).to be true
    # usr = User.new(name: 'tomas', last_name: 'genut', email: 't@a.com')
    # usr.unique_id_setter
    # proj = usr.create_project('some name', 'some_meta.txt')
    # sys.log_project_creation(proj.parm_project_name, usr)
    # s1 = "Project: #{proj.parm_project_name} created "
    # s2 = "by #{usr.unique_id_getter} at"
    # expect(described_class.new.latest_entry).to start_with s1
  end

  # it do
    # sys = described_class.new
    # expect(sys.login('t@t.com')).not_to be_nil
  # end

  it do
    sys = described_class.new
    expect(sys.login('t@a.com')).not_to be_nil
  end

  it do
    sys = described_class.new
    expect(sys.login('t@a.com')).not_to be instance_of(System)
  end

  it do
    sys = described_class.new
    expect{sys.login('t@t.com')}.to raise_error(KeyError)
  end

  it do
    sys = described_class.new
    expect{sys.last_use('time')}.not_to raise_error(KeyError)
  end

  it do
    sys = described_class.new
    expect(sys.last_use('time')).to eq 'sometime'
  end

  it do
    sys = described_class.new
    #usr = User.new(name: 'tomas', last_name: 'genut', email: 't@a.com')
    #usr.unique_id_setter('48c7dcc645d82e57f049bd414daa5ae2')
    expect{sys.login('t@t.com')}.to raise_error(KeyError)
    # usr = User.new(name: 'tomas', last_name: 'genut', email: 't@a.com')
    # usr.unique_id_setter
    # proj = usr.create_project('some name', 'some_meta.txt')
    # sys.log_project_creation(proj.parm_project_name, usr)
    # s1 = "Project: #{proj.parm_project_name} created "
    # s2 = "by #{usr.unique_id_getter} at"
    # expect(described_class.new.latest_entry).to start_with s1
  end
end
