
# LDB

Loosely Developed BIM (building infrastructure management/modeling)

Projektu dokumentų, brėžinių valdymas. Darbo grupių, laiko sekimo, rolių apsaugos funkcionalumas.
Galimybė keistis tekstine, vaizdine informacija tarp vartotojų.

Komanda: Diamond

Elgė Klipčiūtė

Tadas Glumbakas

Paulius Staišiūnas

Aivaras Atkočaitis

Ernestas Kodis

# Tests
Inside LDB_2lab directory:

Run tests with ```rspec spec/*spec.rb```

Run mutations with ```./run.sh```

LDB_2lab coverage: 100%

LDB_3lab coverage: -/-

# Ruby styling check
reek and rubocop is launched regularly inside directory.
