class ProjectsController < ApplicationController
end
