class ProjectManager < ApplicationRecord
end
